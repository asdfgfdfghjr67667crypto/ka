# plugin.video.dramapk
# Required support for improvement: 
- Playlist sort order by Descending (Latest first)
- Marks episodes as watched automatically
- Remembers where you ended the episode, so you can choose to resume the video
